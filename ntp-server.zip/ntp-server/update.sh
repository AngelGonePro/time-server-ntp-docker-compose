#!/usr/bin/env bash
# Rebuilds the chrony image at the versions pinned in .env (picking up Alpine/chrony
# security rebuilds within those pins), verifies the new container syncs and serves NTP,
# and rolls back to the previous image + alerts if it doesn't.
#
#   ./update.sh            rebuild at the pinned versions
#   (bump ALPINE_VERSION / CHRONY_VERSION in .env first to move to a new release)
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

LOG=./update.log
log() { printf '%s %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" | tee -a "$LOG"; }

envval() { sed -n "s/^$1=//p" .env | tail -n1; }
NTP_IMAGE=$(envval NTP_IMAGE)
ALPINE_VERSION=$(envval ALPINE_VERSION)
CHRONY_VERSION=$(envval CHRONY_VERSION)
TIMEOUT=$(envval UPDATE_HEALTH_TIMEOUT); TIMEOUT=${TIMEOUT:-180}
WEBHOOK=$(envval UPDATE_ALERT_WEBHOOK)
TAG="$NTP_IMAGE:$ALPINE_VERSION-$CHRONY_VERSION"
ROLLBACK="$NTP_IMAGE:rollback"
SERVICE=chrony
CONTAINER=ntp-chrony

alert() {
  log "ALERT: $1"
  [ -n "$WEBHOOK" ] || return 0
  if [[ "$WEBHOOK" == *discord.com/api/webhooks* ]]; then
    curl -fsS -m 15 -H 'Content-Type: application/json' \
      -d "{\"content\": \"⚠️ ntp-server ($(hostname)): ${1//\"/\\\"}\"}" "$WEBHOOK" >/dev/null || log "webhook send failed"
  else
    curl -fsS -m 15 -d "ntp-server ($(hostname)): $1" "$WEBHOOK" >/dev/null || log "webhook send failed"
  fi
}

verify() {
  local deadline=$((SECONDS + TIMEOUT)) out
  while (( SECONDS < deadline )); do
    if [ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null)" = "true" ] &&
       out=$(docker exec "$CONTAINER" /usr/local/bin/healthcheck.sh 2>&1); then
      log "verify: $out"
      docker exec "$CONTAINER" chronyc -n tracking | grep -E 'Reference ID|Stratum|System time' | tee -a "$LOG"
      return 0
    fi
    sleep 5
  done
  log "verify failed after ${TIMEOUT}s: ${out:-container not running}"
  docker logs --tail 20 "$CONTAINER" 2>&1 | tee -a "$LOG" || true
  return 1
}

rollback() {
  if ! docker image inspect "$ROLLBACK" >/dev/null 2>&1; then
    alert "$1 — no previous image to roll back to; the server may be down"
    exit 1
  fi
  log "rolling back to previous image"
  docker tag "$ROLLBACK" "$TAG"
  docker compose up -d --no-build --force-recreate "$SERVICE" 2>&1 | tee -a "$LOG"
  if verify; then
    alert "$1 — rolled back to the previous image, which is serving again. Check $LOG."
  else
    alert "$1 — rollback ALSO failed, NTP server is down. Check $LOG."
  fi
  exit 1
}

log "=== update start: target $TAG ==="
mkdir -p "$(envval NTP_DATA_DIR)"

# Keep whatever is running now as the rollback image
current=$(docker inspect -f '{{.Image}}' "$CONTAINER" 2>/dev/null || true)
if [ -n "$current" ]; then
  docker tag "$current" "$ROLLBACK"
  log "saved current image ${current:7:12} as $ROLLBACK"
else
  log "no running container — fresh install"
fi

if ! docker compose build --pull --no-cache "$SERVICE" 2>&1 | tee -a "$LOG"; then
  [ -n "$current" ] && docker tag "$ROLLBACK" "$TAG"
  alert "image build failed for $TAG; running container left untouched"
  exit 1
fi

# Content fingerprint: Alpine release + every installed package version + our scripts.
# (--no-cache always yields a new image ID, so IDs alone can't tell "nothing changed".)
fingerprint() {
  docker run --rm --entrypoint /bin/sh "$1" -c \
    'cat /etc/alpine-release 2>/dev/null; apk info -v 2>/dev/null; cat /usr/local/bin/*.sh' | sort | sha256sum | cut -c1-16
}
new=$(docker image inspect -f '{{.Id}}' "$TAG")
if [ -n "$current" ] && [ "$(fingerprint "$TAG")" = "$(fingerprint "$ROLLBACK")" ]; then
  docker tag "$ROLLBACK" "$TAG"
  docker image rm "$new" >/dev/null 2>&1 || true
  log "no package or script changes — already up to date, container not restarted"
  exit 0
fi

log "new image ${new:7:12} — recreating container"
docker compose up -d --no-build --force-recreate "$SERVICE" 2>&1 | tee -a "$LOG"

if verify; then
  log "=== update OK: $(docker exec "$CONTAINER" chronyd -v) ==="
  docker image prune -f >/dev/null
else
  rollback "update to $TAG failed verification"
fi
