#!/bin/sh
# Healthy = chronyd is synchronised AND actually answers an NTP query on its serving port.
set -eu

out=$(chronyc -n tracking 2>&1) || { echo "chronyc failed: $out"; exit 1; }
if printf '%s\n' "$out" | grep -q 'Leap status *: Not synchronised'; then
  echo "not synchronised"; exit 1
fi

# End-to-end: a one-shot chronyd client queries this server over UDP without touching the clock.
# Host mode bound to one IP doesn't listen on loopback, so query that IP instead.
target=127.0.0.1
if [ "${NTP_NETWORK_MODE:-bridge}" = "host" ] && [ "${NTP_BIND_ADDRESS:-0.0.0.0}" != "0.0.0.0" ]; then
  target=$NTP_BIND_ADDRESS
fi
q=$(chronyd -Q -u chrony -t 5 -f /dev/null "server $target port ${NTP_PORT:-123} iburst maxsamples 1" 2>&1) || {
  echo "NTP query failed: $q"; exit 1; }
printf '%s\n' "$q" | grep -q 'System clock wrong by' || { echo "no NTP reply: $q"; exit 1; }

echo "ok"
